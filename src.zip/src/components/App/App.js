import React from "react";
import AnkiDeck from "../AnkiDeck/AnkiDeck";

export default () => {
  return (
    <div
      style={{
        background: "linear-gradient(to right bottom, #fff7ff, #eeffff)",
        height: "100vh",
      }}
    >
      {" "}
      <AnkiDeck />
    </div>
  );
};
